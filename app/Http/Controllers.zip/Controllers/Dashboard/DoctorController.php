<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Doctor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DoctorController extends Controller
{
    public function index()
    {
        $doctors = Doctor::get();
        return view('dashboard.doctors.index', compact('doctors'));
    }

    public function create(){
        return view('dashboard.doctors.create');
    }
    public function store(Request $request){
        $request->validate([
            'name_en' => 'required',
            'name_ar' => 'required',
            'gender' => 'required',
            'email' => 'required|email|unique:doctors,email',
            'password' => 'required',
            'phone' => 'required|unique:doctors,phone',
            'specialization_en' => 'required',
            'specialization_ar' => 'required',
            'level_en' => 'required',
            'level_ar' => 'required',
            'university_en' => 'required',
            'university_ar' => 'required',
            'image' => 'mimes:jpeg,jpg,png,gif|required|max:10000',
        ], [
            'name_en.required' => 'الاسم مطلوب',
            'name_ar.required' => 'الاسم مطلوب',
            'email.required' => 'البريد الالكتروني مطلوب',
            'email.unique' => 'البريد الالكتروني موجود من قبل',
            'password.required' => 'الرقم السري مطلوب',
            'phone.required' => 'رقم الهاتف مطلوب',
            'phone.unique' => 'رقم الهاتف موجود من قبل',

            'specialization_en.required' => 'الشركة مطلوبة',
            'specialization_ar.required' => 'الشركة مطلوبة',
            'level_en.required' => 'الشركة مطلوبة',
            'level_ar.required' => 'الشركة مطلوبة',
            'university_en.required' => 'الشركة مطلوبة',
            'university_ar.required' => 'الشركة مطلوبة',
            'image.required' => 'الصورة مطلوبة',
        ]);
        DB::beginTransaction();
        $file = $request->file('image');
            $ext = $file->getClientOriginalName();
            $filename = "doctor-" . uniqid() . ".$ext";
            $file->move(public_path('images/doctors'), $filename);

        Doctor::create([
            'name_en' => $request->name_en,
            'name_ar' => $request->name_ar,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'phone' => $request->phone,
            'gender' => $request->gender,
            'specialization_en' => $request->specialization_en,
            'specialization_ar' => $request->specialization_ar,
            'level_en' => $request->level_en,
            'level_ar' => $request->level_ar,
            'university_en' => $request->university_en,
            'university_ar' => $request->university_ar,
            'photo' =>  $filename,
        ]);
        DB::commit();
        return redirect()->route('doctors.index')->with(['success' => 'Doctor Added Successfully']);
    }
    public function edit($id)
    {
        $doctor = Doctor::findOrFail($id);
        return view('dashboard.doctors.edit', compact('doctor'));
    }
    public function update(Request $request, $id)
    {
        // return $request;
        $request->validate([
            'name_en' => 'required',
            'name_ar' => 'required',
            'gender' => 'required',
            'email' => 'required|email|unique:doctors,email,' . $id,
            // 'password' => 'required',
            'phone' => 'required|unique:doctors,phone,' . $id,
            'specialization_en' => 'required',
            'specialization_ar' => 'required',
            'level_en' => 'required',
            'level_ar' => 'required',
            'university_en' => 'required',
            'university_ar' => 'required',
            // 'image' => 'mimes:jpeg,jpg,png,gif|required|max:10000',
        ], [
            'name_en.required' => 'الاسم مطلوب',
            'name_ar.required' => 'الاسم مطلوب',
            'email.required' => 'البريد الالكتروني مطلوب',
            'email.unique' => 'البريد الالكتروني موجود من قبل',
            'password.required' => 'الرقم السري مطلوب',
            'phone.required' => 'رقم الهاتف مطلوب',
            'phone.unique' => 'رقم الهاتف موجود من قبل',

            'specialization_en.required' => 'الشركة مطلوبة',
            'specialization_ar.required' => 'الشركة مطلوبة',
            'level_en.required' => 'الشركة مطلوبة',
            'level_ar.required' => 'الشركة مطلوبة',
            'university_en.required' => 'الشركة مطلوبة',
            'university_ar.required' => 'الشركة مطلوبة',
            // 'image.required' => 'الصورة مطلوبة',
        ]);
        $doctor = Doctor::findOrFail($id);
        DB::beginTransaction();
        $doctor->update([
            'name_en' => $request->name_en,
            'name_ar' => $request->name_ar,
            'email' => $request->email,
            'phone' => $request->phone,
            'gender' => $request->gender,
            'specialization_en' => $request->specialization_en,
            'specialization_ar' => $request->specialization_ar,
            'level_en' => $request->level_en,
            'level_ar' => $request->level_ar,
            'university_en' => $request->university_en,
            'university_ar' => $request->university_ar,
        ]);
        DB::commit();
        return redirect()->route('doctors.index')->with(['success' => 'Doctor Edited Successfully']);
    }
    public function delete($id)
    {
        Doctor::findOrFail($id)->delete();
        return redirect()->route('doctors.index')->with(['success' => 'Doctor Deleted Successfully']);
    }
}
