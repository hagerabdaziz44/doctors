<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Patient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class PatientController extends Controller
{
    public function index(){
        $clients =  Patient::paginate(20);
        return view('dashboard.patients.index',compact('clients'));
    }


    public function create(){
        return view('dashboard.patients.create');
    }

    public function store(Request $request){

        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:patients,email',
            'gender' => 'required',
            'phone' => 'required',
            'birth_date'=>'required',

        ],[
            'name.required' => 'الاسم مطلوب',
            'email.required' => 'البريد الالكتروني مطلوب',
            'email.unique' => 'البريد الالكتروني موجود من قبل',

            'gender.required' => 'النوع مطلوب',
            'phone.required' => 'رقم الهاتف مطلوب',
            'birth_date.required'=>'تاريخ الميلاد مطلوب',
        ]);

         DB::beginTransaction();
         $fillname="";
        Patient::create([
            'name' => $request->name,
            'email' => $request->email,
            'gender' => $request->gender,
            'phone' => $request->phone,
            'birth_date'=>$request->birth_date,
            'photo'=>$fillname,
        ]);
         DB::commit();
        return redirect()->route('admin.patients.index')->with(['success' => 'تم اضافة العميل بنجاح']);
    }
    public function edit($id){
        $client = Patient::findOrFail($id);
        return view('dashboard.patients.edit',compact('client'));
    }

    public function update(Request $request, $id)
    {
        $client = Patient::findOrFail($id);
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:patients,email,'.$id,
            'gender' => 'required',
            'phone' => 'required',
        ],[
            'name.required' => 'الاسم مطلوب',
            'email.required' => 'البريد الالكتروني مطلوب',
            'email.unique' => 'البريد الالكتروني موجود من قبل',
            'status.required' => 'الحالة مطلوبة',
            'gender.required' => 'النوع مطلوب',
            'phone.required' => 'رقم الهاتف مطلوب',
        ]);

        DB::beginTransaction();
        $client->update([
            'name' => $request->name,
            'email' => $request->email,
            'gender' => $request->gender,
            'phone' => $request->phone,
            'birth_date'=>$request->birth_date,
        ]);
        DB::commit();
        return redirect()->route('admin.patients.index')->with(['success' => 'تم تعديل العميل بنجاح']);
    }

    public  function delete($id){
        Patient::findOrFail($id)->delete();
        return redirect()->route('admin.patients.index')->with(['success' => 'تم مسح العميل بنجاح']);
    }

}
