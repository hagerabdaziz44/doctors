<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Clinic;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ClinicController extends Controller
{
    public function index()
    {
        $clinics = Clinic::get();
        return view('dashboard.clinics.index', compact('clinics'));
    }
    public function create()
    {
        return view('dashboard.clinics.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'name_en' => 'required',
            'name_ar' => 'required',
            'phone' => 'required|unique:clinics,phone',
            'address_en' => 'required',
            'address_ar' => 'required',
            'lat' => 'required',
            'long' => 'required',

        ], [
            'name_en.required' => 'الاسم مطلوب',
            'name_ar.required' => 'الاسم مطلوب',

            'phone.required' => 'رقم الهاتف مطلوب',
            'phone.unique' => 'رقم الهاتف موجود من قبل',

            'address_en.required' => 'الشركة مطلوبة',
            'address_ar.required' => 'الشركة مطلوبة',
            'lat.required' => 'الشركة مطلوبة',
            'long.required' => 'الشركة مطلوبة',

        ]);
        DB::beginTransaction();

        Clinic::create([
            'name_en' => $request->name_en,
            'name_ar' => $request->name_ar,
            'phone' => $request->phone,

            'address_en' => $request->address_en,
            'address_ar' => $request->address_ar,
            'lat' => $request->lat,
            'long' => $request->long,

        ]);
        DB::commit();
        return redirect()->route('clinics.index')->with(['success' => 'Clinic Added Successfully']);
    }
    public function edit($id)
    {
        $clinic = Clinic::findOrFail($id);
        return view('dashboard.clinics.edit', compact('clinic'));
    }
    public function update(Request $request, $id)
    {
        // return $request;
        $request->validate([
            'name_en' => 'required',
            'name_ar' => 'required',
            'phone' => 'required|unique:clinics,phone,' . $id,

            'address_en' => 'required',
            'address_ar' => 'required',
            'lat' => 'required',
            'long' => 'required',

        ], [
            'name_en.required' => 'الاسم مطلوب',
            'name_ar.required' => 'الاسم مطلوب',

            'phone.required' => 'رقم الهاتف مطلوب',
            'phone.unique' => 'رقم الهاتف موجود من قبل',

            'address_en.required' => 'الشركة مطلوبة',
            'address_ar.required' => 'الشركة مطلوبة',
            'lat.required' => 'الشركة مطلوبة',
            'long.required' => 'الشركة مطلوبة',

        ]);
        $clinic = Clinic::findOrFail($id);
        DB::beginTransaction();
        $clinic->update([
            'name_en' => $request->name_en,
            'name_ar' => $request->name_ar,
            'phone' => $request->phone,

            'address_en' => $request->address_en,
            'address_ar' => $request->address_ar,
            'lat' => $request->lat,
            'long' => $request->long,
        ]);
        DB::commit();
        return redirect()->route('clinics.index')->with(['success' => 'Clinic Edited Successfully']);
    }
    public function delete($id)
    {
        Clinic::findOrFail($id)->delete();
        return redirect()->route('clinics.index')->with(['success' => 'Clinic Deleted Successfully']);
    }
}
