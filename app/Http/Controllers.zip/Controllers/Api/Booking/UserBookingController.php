<?php

namespace App\Http\Controllers\Api\Booking;

use App\Http\Controllers\Controller;
use App\Models\PatientBooking;
use App\Models\DoctorAppointmentDetail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class UserBookingController extends Controller
{
    public function book(Request $request)
    {
        PatientBooking::create([
            'clinic_id'=>$request->clinic_id,
            'patient_id'=>Auth::guard('user-api')->user()->id,
            'doctor_id'=>$request->doctor_id,
            'doctor_appointment_detail_id'=>$request->doctor_appointment_detail_id,
            'lat'=>$request->lat,
            'long'=>$request->long,
            'date'=>$request->date,
            'fee'=>$request->fee,
        ]);
        return response()->json([
            'message' => 'تم الحجز بنجاح',
           
        ]);    
          

    }
    public function available_times(Request $request)
    {
      $all= PatientBooking::where('date',$request->date)->where('doctor_id',$request->doctor_id)->where('clinic_id',$request->clinic_id)->where('status','!=','rejected')->get(['doctor_appointment_detail_id']);
      $available_times=DoctorAppointmentDetail::whereNotIn('id',$all)->where('day_id',$request->day_id)->with(['days' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}])->where('clinic_id',$request->clinic_id)->get();
      return response()->json([
        'message' => 'success',
        'available_times'=> $available_times
    ]);    
      

    }
    public function get_my_bookinglist(Request $request)
    {
       $all= PatientBooking::where('patient_id',Auth::guard('user-api')->user()->id)->with(
        [
        'doctor' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');},
        'clinic' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}])->get();;
       return response()->json([
        'message' => 'success',
        'all'=> $all
    ]);   

    }
}
