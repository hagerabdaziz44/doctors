<?php

namespace App\Http\Controllers\Api\Banners;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

class BannersController extends Controller
{
    public function index()
    {
        $banners=Banner::get();
        return Response::json(array(
            'status'=>200,
            'message'=>'true',
            'banners'=>$banners,
            ));
    }

}
