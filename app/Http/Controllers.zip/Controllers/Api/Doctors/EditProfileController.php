<?php

namespace App\Http\Controllers\Api\Doctors;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Doctor;
use App\Models\DoctorInsurance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;

class EditProfileController extends Controller
{
    public function Editprofile(Request $request)
    {

        $validator = Validator::make(
            $request->all(),
            [
                'name_en' => 'required|string',
                'name_ar' => 'required|string',
                'email' => 'required|unique:doctors,email,' . auth('clinic-api')->user()->id,
                'phone' => 'required|unique:doctors,phone,' . auth('clinic-api')->user()->id,
                'gender' => 'required|string',
                'level_en' => 'required',
                'level_ar' => 'required',
                'university_en' => 'required',
                'university_ar' => 'required',

                'photo' => 'nullable|image',
                'insurance_id' => 'required|exists:insurances,id',
                'doctor_id' => 'required|exists:doctors,id',
                // 'clinic_id' => 'required|exists:clinics,id'

            ],
            [
                'name_en.required' => trans('editProfile.nameRequired'),
                'name_en.string' => trans('editProfile.nameString'),
                'name_ar.required' => trans('editProfile.nameRequired'),
                'name_ar.string' => trans('editProfile.nameString'),
                'phone.required' => trans('editProfile.phoneRequired'),
                'photo.required' => trans('editProfile.photoRequired'),
                'photo.image' => trans('editProfile.photoImage'),
                'email.required' => trans('editProfile.emailRequired'),
                'email.unique' => trans('editProfile.emailUnique'),
                'level_en.required' => trans('doctor.level_en'),
                'level_ar.required' => trans('doctor.level_ar'),
                'university_en.required' => trans('doctor.university_en'),
                'university_ar.required' => trans('doctor.university_ar'),
                'gender.required' => trans('doctor.gender'),
                'insurance_id.required' => trans('doctor.insurance_id'),
                'insurance_id.exists' => trans('doctor.insurance_id_exists'),
                'doctor_id.required' => trans('doctor.doctor_id'),
                'doctor_id.exists' => trans('doctor.doctor_id_exists'),
                // 'clinic_id.required' => trans('doctor.clinic_id'),
                // 'clinic_id.exists' => trans('doctor.clinic_id_exists')


            ]
        );
        if ($validator->fails()) {
            return response()->json([
                'message' => $validator->errors()->first()
            ]);
        }



        $doctor = Doctor::where('clinic_id', Auth::guard('clinic-api')->user()->id)->where('id', $request->doctor_id)->first();
        DB::beginTransaction();
        $name = $doctor->photo;
        if ($request->hasFile('photo')) {

            $photo = $request->file('photo');
            $ext = $photo->getClientOriginalName();
            $name = "doctor-" . uniqid() . ".$ext";
            $photo->move(public_path('images/doctors'), $name);
        }

        $doctor->update([

            'name_en' => $request->name_en,
            'name_ar' => $request->name_ar,
            'email' => $request->email,
            'phone' => $request->phone,
            'specialization_id' => $request->specialization_id,
            'level_en' => $request->level_en,
            'level_ar' => $request->level_ar,
            'university_en' => $request->university_en,
            'university_ar' => $request->university_ar,
            'gender' => $request->gender,
            'photo' => $name,
            // 'insurance_id' => $request->insurance_id,
            'clinic_id' => Auth::guard('clinic-api')->user()->id
        ]);
        if($request->insurance_id)
        {
            DoctorInsurance::where('doctor_id',$doctor->id)->delete();
                foreach ($request->insurance_id as $i)
                {
                   DoctorInsurance::create([
                    'doctor_id'=>$doctor->id,
                    'insurance_id'=>$i,
                   ]);
                }
        }

        DB::commit();
        return Response::json(array(
            'message' => trans('msg.updateSuccess'),
        ));
    }
    public function change_password(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'old_password' => 'required',
            'password' => 'required|min:6|max:100',
            'confirm_password' => 'required|same:password'
        ], [

            'password.required' => trans('editProfile.passwordRequired'),
            'confirm_password.required' => trans('editProfile.confirm_passwordRequired'),
            'confirm_password.same' => trans('editProfile.confirm_passwordSame'),
        ]);
        if ($validator->fails()) {
            return response()->json([
                'message' => $validator->errors()->first(), 'status' => 422
            ]);
        }
        $user = Auth::guard('doctor-api')->user();
        if (Hash::check($request->old_password, $user->password)) {
            Doctor::findOrfail(Auth::guard('doctor-api')->user()->id)->update([
                'password' => Hash::make($request->password)
            ]);
            return response()->json([
                'message' => trans('msg.pwSuccess'),
            ], 200);
        } else {
            return response()->json([
                'message' => trans('msg.pwError'),
            ], 400);
        }
    }

    public function delete_doctor(Request $request){
        $validator = Validator::make(
            $request->all(),
            [
                'doctor_id' => 'required|exists:doctors,id'
            ],
            [
                'doctor_id.required' => trans('doctor.doctor_id'),
                'doctor_id.exists' => trans('doctor.doctor_id_exists'),
            ]
        );
        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()]);
        }
      Doctor::where('clinic_id', Auth::guard('clinic-api')->user()->id)->where('id', $request->doctor_id)->delete();
      return Response::json(array(
        'message' => trans('doctor.delete'),
    ));
    }
}
