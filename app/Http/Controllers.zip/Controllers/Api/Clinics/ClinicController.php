<?php

namespace App\Http\Controllers\Api\Clinics;

use App\Http\Controllers\Controller;
use App\Models\Clinic;
use App\Models\Doctor;
use App\Models\ClinicInsurance;
use App\Models\ClinicSpecialization;
use Illuminate\Http\Request;

class ClinicController extends Controller
{
    public function all_clinics(){
        $clinics = Clinic::select('id','description_'.app()->getLocale() .' as description','name_'.app()->getLocale() .' as name','phone','address_'.app()->getLocale() .' as address','lat','long','logo','cover','rate')->get();
        $clinics->map(function ($clinics){

            $clinics['insurances']=ClinicInsurance::where('clinic_id',$clinics['id'])->with(['insurance' => function ($q) { $q->select('id','body_'.app()->getLocale() .' as body','title_'.app()->getLocale() .' as title','photo');}])->get();
         
    
        });
        $clinics->map(function ($clinics){

            $clinics['specializations']=ClinicSpecialization::where('clinic_id',$clinics['id'])->with(['specialization' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}])->get();
         
    
        });
        $clinics->map(function ($clinics){

            $clinics['doctors']=Doctor::where('clinic_id',$clinics['id'])->select('id','name_'.app()->getLocale() .' as name')->with(['specializations' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}])->get();
         
    
        });
        return response()->json([
            'message' => 'success',
            'clinics'   => $clinics
        ]);
    }
    public function get_clinic_by_id(Request $request)
    {
        $clinics = Clinic::where('id',$request->clinic_id)->select('id','description_'.app()->getLocale() .' as description','name_'.app()->getLocale() .' as name','phone','address_'.app()->getLocale() .' as address','lat','long','logo','cover','rate')->get();
        $clinics->map(function ($clinics){

            $clinics['insurances']=ClinicInsurance::where('clinic_id',$clinics['id'])->with(['insurance' => function ($q) { $q->select('id','body_'.app()->getLocale() .' as body','title_'.app()->getLocale() .' as title','photo');}])->get();
         
    
        });
        $clinics->map(function ($clinics){

            $clinics['specializations']=ClinicSpecialization::where('clinic_id',$clinics['id'])->with(['specialization' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}])->get();
         
    
        });
        $clinics->map(function ($clinics){

            $clinics['doctors']=Doctor::where('clinic_id',$clinics['id'])->select('id','name_'.app()->getLocale() .' as name')->with(['specializations' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}])->get();
         
    
        });
        return response()->json([
            'message' => 'success',
            'clinics'   => $clinics
        ]);

    }
    public function get_clincics_by_specialization_id(Request $request)
    {
        $all = ClinicSpecialization::where('id',$request->special_id)->get(['clinic_id']); 
        $clinics = Clinic::whereIn('id',$all)->select('id','description_'.app()->getLocale() .' as description','name_'.app()->getLocale() .' as name','phone','address_'.app()->getLocale() .' as address','lat','long','logo','cover','rate')->get();
        $clinics->map(function ($clinics){

            $clinics['insurances']=ClinicInsurance::where('clinic_id',$clinics['id'])->with(['insurance' => function ($q) { $q->select('id','body_'.app()->getLocale() .' as body','title_'.app()->getLocale() .' as title','photo');}])->get();
         
    
        });
        $clinics->map(function ($clinics){

            $clinics['specializations']=ClinicSpecialization::where('clinic_id',$clinics['id'])->with(['specialization' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}])->get();
         
    
        });
        $clinics->map(function ($clinics){

            $clinics['doctors']=Doctor::where('clinic_id',$clinics['id'])->select('id','name_'.app()->getLocale() .' as name')->with(['specialization' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}])->get();
         
    
        });
        return response()->json([
            'message' => 'success',
            'clinics'   => $clinics
        ]);
        
    }
    public function get_clincics_by_insurance_id(Request $request)
    {
        $all = ClinicSpecialization::where('id',$request->insurance_id)->get(['clinic_id']); 
        $clinics = Clinic::whereIn('id',$all)->select('id','description_'.app()->getLocale() .' as description','name_'.app()->getLocale() .' as name','phone','address_'.app()->getLocale() .' as address','lat','long','logo','cover','rate')->get();
        $clinics->map(function ($clinics){

            $clinics['insurances']=ClinicInsurance::where('clinic_id',$clinics['id'])->with(['insurance' => function ($q) { $q->select('id','body_'.app()->getLocale() .' as body','title_'.app()->getLocale() .' as title','photo');}])->get();
         
    
        });
        $clinics->map(function ($clinics){

            $clinics['specializations']=ClinicSpecialization::where('clinic_id',$clinics['id'])->with(['specialization' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}])->get();
         
    
        });
        $clinics->map(function ($clinics){

            $clinics['doctors']=Doctor::where('clinic_id',$clinics['id'])->select('id','name_'.app()->getLocale() .' as name')->with(['specializations' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}])->get();
         
    
        });
        return response()->json([
            'message' => 'success',
            'clinics'   => $clinics
        ]);
        
    }
}
