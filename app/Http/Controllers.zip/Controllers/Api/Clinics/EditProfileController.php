<?php

namespace App\Http\Controllers\Api\Clinics;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Clinic;
use App\Models\Doctor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;

class EditProfileController extends Controller
{
    public function Editprofile(Request $request)
    {

            $validator = Validator::make($request->all(),[
                'name_en'=>'required|string',
                'name_ar'=>'required|string',

                'phone' => 'required|unique:clinics,phone,'.auth('clinic-api')->user()->id,

                'address_en' => 'required',
                'address_ar' => 'required',
                'lat' => 'required',
                'long' => 'required',


            ]
        ,[
            'name_en.required'=>trans('editProfile.nameRequired'),
            'name_en.string'=>trans('editProfile.nameString'),
            'name_ar.required'=>trans('editProfile.nameRequired'),
            'name_ar.string'=>trans('editProfile.nameString'),
            'phone.required'=>trans('editProfile.phoneRequired'),


            'address_en.required' => trans('doctor.address_en'),
            'address_ar.required' => trans('doctor.address_ar'),
            'lat.required' => trans('doctor.lat'),
            'long.required' => trans('doctor.long'),



        ]);
        if ($validator->fails()) {
            return response()->json([
                'message'=>$validator->errors()->first()
            ]);
        }



            $clinic=Clinic::where('id',Auth::guard('clinic-api')->user()->id)->first();
            DB::beginTransaction();


                        $clinic->update([

                            'name_en' => $request->name_en,
                            'name_ar' => $request->name_ar,
                            'phone' => $request->phone,
                            'address_en' => $request->address_en,
                            'address_ar' => $request->address_ar,
                            'lat' => $request->lat,
                            'long' => $request->long,


                        ]);
                        DB::commit();
                        return Response::json(array(
                        'message'=>trans('msg.updateSuccess'),
                        ));

    }
    public function change_password(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'old_password'=>'required',
            'password'=>'required|min:6|max:100',
            'confirm_password'=>'required|same:password'
        ],[

            'password.required' =>trans('editProfile.passwordRequired'),
            'confirm_password.required'=>trans('editProfile.confirm_passwordRequired'),
            'confirm_password.same'=>trans('editProfile.confirm_passwordSame'),
        ]);
        if ($validator->fails()) {
            return response()->json([
                'message'=>$validator->errors()->first(),'status'=> 422
            ]);
        }
        $user=Auth::guard('doctor-api')->user();
        if(Hash::check($request->old_password,$user->password)){
            Doctor::findOrfail(Auth::guard('doctor-api')->user()->id)->update([
                'password'=>Hash::make($request->password)
            ]);
            return response()->json([
                'message'=>trans('msg.pwSuccess'),
            ],200);
        }else
        {
            return response()->json([
                'message'=>trans('msg.pwError'),
            ],400);
        }

    }
}
