<?php

namespace App\Http\Services;

use App\Models\User;
use App\Models\ManagerVerification;

use Illuminate\Support\Facades\Auth;


class ManagerVerificationServices
{
    /** set OTP code for mobile
     * @param $data
     *
     * @return User_verfication
     */
    public function setVerificationCode($data)
    {
        $code = mt_rand(100000, 999999);
        $data['code'] = $code;
        ManagerVerification::whereNotNull('user_id')->where(['user_id' => $data['user_id']])->delete();
        return ManagerVerification::create($data);
    }

    public function getSMSVerifyMessageByAppName( $code)
    {
            $message = " is your verification code for your account";
             return $code;
    }




}
