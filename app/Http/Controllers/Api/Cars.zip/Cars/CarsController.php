<?php

namespace App\Http\Controllers\Api\Cars;

use App\Http\Controllers\Controller;
use App\Models\Car;
use App\Models\CarColor;
use App\Models\Color;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

class CarsController extends Controller
{
public function index()
{
    $cars=Car::select('id','name_'.app()->getLocale() .' as name','description_'.app()->getLocale() .' as description','images','price','car_model_id','brand_id','company_id')-> with(
        ['companies' => function ($q) {$q->select('id','name_'.app()->getLocale() .' as name');},
        'brands' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');},
        'models' => function ($q) { $q->select('id','year');},
        ])->get();
 ;
    $colors=CarColor::all();

        $cars->map(function ($cars){

        $colors=CarColor::where('car_id',$cars['id'])->get();
        $car['color']=$colors->pluck('color_id');

         $cars['colors']=Color::whereIn('id',$car['color'])->select('id','name_'.app()->getLocale() .' as name')->get();
});

    return Response::json(array(
        'cars'=>$cars,
        'message'=>'success',
        ));
}
}
