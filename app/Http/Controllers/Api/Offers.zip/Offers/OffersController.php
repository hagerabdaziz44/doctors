<?php

namespace App\Http\Controllers\Api\Offers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class OffersController extends Controller
{
    public function index()
    {
        $offers=Offer::select('id','name_'.app()->getLocale() .' as name','body_'.app()->getLocale() .' as body','clinic_id','created_at',
        )->with(
            [
               
                'clinic' => function ($q) { $q->select('id','description_'.app()->getLocale() .' as description','name_'.app()->getLocale() .' as name','phone','address_'.app()->getLocale() .' as address','lat','long','logo','cover','rate');},'doctorappointment'=> function ($q) { $q->with(['days' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}]);}])->get();get();
        return Response::json(array(
            'status'=>200,
            'message'=>'true',
            'offers'=>$offers,
            ));
       
    }

    public function store(Request $request)
    {
       
         $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',
            'body_ar'=>'required',
            'body_en'=>'required',
            'clinic_id'=>'required',
        ]);
       
        // try {

            DB::beginTransaction();

       

       Offer::create([
            'name_ar'=>$request->name_ar,
            'name_en'=>$request->name_en,
            'body_ar'=>$request->body_ar,
            'body_en'=>$request->body_en,
            'clinic_id'=>$request->clinic_id,
        
        ]);

        DB::commit();
        return Response::json(array(
                        'status'=>200,
                        'message'=>'Added Sucessfully',
                        ));
                }

       public function get_offer_by_id(Request $request)
    {
        $offers=Offer::where('id',$request->id)->select('id','name_'.app()->getLocale() .' as name','body_'.app()->getLocale() .' as body','clinic_id','created_at',
        )->with(
            [
               
                'clinic' => function ($q) { $q->select('id','description_'.app()->getLocale() .' as description','name_'.app()->getLocale() .' as name','phone','address_'.app()->getLocale() .' as address','lat','long','logo','cover','rate');},'doctorappointment'=> function ($q) { $q->with(['days' => function ($q) { $q->select('id','name_'.app()->getLocale() .' as name');}]);}])->get();get();
        return Response::json(array(
            'status'=>200,
            'message'=>'true',
            'offers'=>$offers,
            ));
       
       

    }
    public function update(Request $request, Offer $offer)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',
            'clinic_id'=>'required',
        ],[
            'name_en.required' => 'الاسم مطلوب',
            'name_ar.required' => 'الاسم مطلوب',


        ]);
        $offer->name_ar = $request->name_ar;
        $offer->name_en = $request->name_en;
        
        $offer->body_ar = $request->body_ar;
        $offer->body_en = $request->body_en;
        $offer->clinic_id = $request->clinic_id;

        $offer->save();
        return redirect(route('admin.offers.index'))->with(['success' => 'تم  تعديل المقال بنجاح']);

    }
    public function destroy(offer $offer)
    {
        $offer->delete();
        return redirect(route('admin.offers.index'))->with(['success' => 'تم   حذف المقال بنجاح']);

    }
}
