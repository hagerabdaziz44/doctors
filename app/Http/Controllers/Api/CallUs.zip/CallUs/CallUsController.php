<?php

namespace App\Http\Controllers\Api\CallUs;

use App\Http\Controllers\Controller;
use App\Models\CallUs;
use Illuminate\Http\Request;

class CallUsController extends Controller
{
    public function callus(Request $request)
    {
        CallUs::create([
            'name'=>$request->name,
            'phone'=>$request->phone,
            'email'=>$request->email,
            'body'=>$request->body,
            'patient_id'=>Auth::guard('user-api')->user()->id,
        ]);
        return response()->json([
            'message' => 'تم الارسال بنجاح',
        ]);    
          

    }
}
