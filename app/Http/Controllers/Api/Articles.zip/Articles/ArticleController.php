<?php

namespace App\Http\Controllers\Api\Articles;

use App\Http\Controllers\Controller;
use App\Models\Article;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

class ArticleController extends Controller
{
    public function index()
    {
        $articles=Article::get();
        return Response::json(array(
            'status'=>200,
            'message'=>'true',
            'articles'=>$articles,
            ));
    }
}
